﻿using System;
namespace ModelService
{
    public class DataProtectionKeys
    {
        public string ApplicationUserKey { get; set; }
        public string SendGridProtectionKey { get; set; }
    }
}
