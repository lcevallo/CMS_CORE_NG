﻿using System;
using Microsoft.AspNetCore.Authentication;

namespace FiltersService
{
    public class AdminAuthenticationOptions : AuthenticationSchemeOptions
    {
       
    }
}
