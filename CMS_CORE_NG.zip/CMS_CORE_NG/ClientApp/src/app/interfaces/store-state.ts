export interface StoreState {
    loggedInStatus: boolean;
}
