export interface Country {
    states: string;
    flag: string;
    id: number;
    name: string;
    twoDigitCode: string;
}
