export interface Login {
    username: string;
    password: string;
    rememberMe: boolean;
    grant_type: string;
}
